const {
  Deposit,
  Withdrawal,
  Transfer,
  Payment,
  Movement,
  FeeMovement
} = require('../models');

const registry = new Map([
  ['INCOME', Deposit],
  ['EXPENSE', Withdrawal],
  ['TRANSFER', Transfer],
  ['PAYMENT', Payment],
  ['FEE', FeeMovement]   
]);

function register(type, ctor) {
  registry.set(type.toUpperCase(), ctor);
}

function createMovement(data = {}) {
  const type = (data.type || '').toUpperCase();

  const Ctor = registry.get(type);
  if (!Ctor) {
    return new Movement(data); 
  }

  return new Ctor(data);
}

module.exports = { createMovement, register, registry };
