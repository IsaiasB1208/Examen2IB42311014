class FeeMovement extends Movement {
  constructor(data) {
    super(data);
    this.type = 'FEE';
  }

  netAmount() {
    return -Math.abs(this.amount || 0);
  }
}
