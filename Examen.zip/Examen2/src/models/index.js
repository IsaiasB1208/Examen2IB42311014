const Deposit = require('./Deposit');
const Withdrawal = require('./Withdrawal');
const Transfer = require('./Transfer');
const Payment = require('./Payment');
const Movement = require('./Movement');
const { FeeMovement } = require('./Movement');   

module.exports = {
  Deposit,
  Withdrawal,
  Transfer,
  Payment,
  Movement,
  FeeMovement
};
