import React from "react";
import "./MovementList.css";
import MovementCard from "./MovementCard";
import { createMovement } from "../domain/MovementFactory";

export default function MovementList({ movements }) {
  return (
    <div className="movement-list">
      {movements.map((m, index) => {
        const movementInstance = createMovement(m); 

        return (
          <MovementCard 
            key={index}
            movement={movementInstance}
          />
        );
      })}
    </div>
  );
}
